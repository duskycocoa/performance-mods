package me.flashyreese.mods.sodiumextra.common.util;

import me.jellysquid.mods.sodium.client.gui.options.control.ControlValueFormatter;
import net.minecraft.class_2585;
import net.minecraft.class_2588;
import net.minecraft.class_310;
import net.minecraft.class_313;

public interface ControlValueFormatterExtended extends ControlValueFormatter {
    static ControlValueFormatter resolution() {
        class_313 monitor = class_310.method_1551().method_22683().method_20831();
        return (v) -> {
            if (monitor == null) {
                return new class_2588("options.fullscreen.unavailable").getString();
            } else {
                return v == 0 ? new class_2588("options.fullscreen.current").getString() : new class_2585(monitor.method_1620(v - 1).toString()).getString();
            }
        };
    }

    static ControlValueFormatter fogDistance() {
        return (v) -> {
            if (v == 0) {
                return new class_2588("generator.default").getString();
            } else if (v == 33) {
                return new class_2588("options.off").getString();
            } else {
                return new class_2588("options.chunks", v).getString();
            }
        };
    }
}
