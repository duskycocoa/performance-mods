package me.flashyreese.mods.sodiumextra.mixin.sky;

import me.flashyreese.mods.sodiumextra.client.SodiumExtraClientMod;
import net.minecraft.class_1159;
import net.minecraft.class_291;
import net.minecraft.class_293;
import net.minecraft.class_4587;
import net.minecraft.class_761;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_761.class)
public class MixinWorldRenderer {
    @Redirect(
            method = "renderSky",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/gl/VertexBuffer;bind()V",
                    ordinal = 0
            )
    )
    public void redirectVertexBufferBind(class_291 instance) {
        if (SodiumExtraClientMod.options().detailSettings.sky) {
            instance.method_1353();
        }
    }

    @Redirect(
            method = "renderSky",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/render/VertexFormat;startDrawing(J)V",
                    ordinal = 0
            )
    )
    public void redirectVertexFormatStartDrawing(class_293 instance, long pointer) {
        if (SodiumExtraClientMod.options().detailSettings.sky) {
            instance.method_22649(pointer);
        }
    }

    @Redirect(
            method = "renderSky",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/gl/VertexBuffer;draw(Lnet/minecraft/util/math/Matrix4f;I)V",
                    ordinal = 0
            )
    )
    public void redirectVertexBufferDraw(class_291 instance, class_1159 matrix, int mode) {
        if (SodiumExtraClientMod.options().detailSettings.sky) {
            instance.method_1351(matrix, mode);
        }
    }

    @Redirect(
            method = "renderSky",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/gl/VertexBuffer;unbind()V",
                    ordinal = 0
            )
    )
    public void redirectVertexBufferUnbind() {
        if (SodiumExtraClientMod.options().detailSettings.sky) {
            class_291.method_1354();
        }
    }

    @Redirect(
            method = "renderSky",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/render/VertexFormat;endDrawing()V",
                    ordinal = 0
            )
    )
    public void redirectVertexFormatEndDrawing(class_293 instance) {
        if (SodiumExtraClientMod.options().detailSettings.sky) {
            instance.method_22651();
        }
    }

    @Inject(method = "renderEndSky", at = @At(value = "HEAD"), cancellable = true)
    public void preRenderEndSky(class_4587 matrices, CallbackInfo ci) {
        if (!SodiumExtraClientMod.options().detailSettings.sky) {
            ci.cancel();
        }
    }
}
