package me.flashyreese.mods.sodiumextra.mixin.compat;

import me.flashyreese.mods.sodiumextra.client.SodiumExtraClientMod;
import me.flashyreese.mods.sodiumextra.client.gui.SuggestRSOScreen;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_2561;
import net.minecraft.class_437;
import net.minecraft.class_442;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_442.class)
public abstract class MixinTitleScreen extends class_437 {

    protected MixinTitleScreen(class_2561 title) {
        super(title);
    }

    @Inject(method = "init", at = @At(value = "RETURN"))
    private void postInit(CallbackInfo ci) {
        if (!FabricLoader.getInstance().isModLoaded("reeses-sodium-options") && !SodiumExtraClientMod.options().notificationSettings.hideRSORecommendation && !SodiumExtraClientMod.options().hasSuggestedRSO()) {
            this.field_22787.method_1507(new SuggestRSOScreen(this));
            SodiumExtraClientMod.options().setSuggestedRSO(true);
        }
    }
}
