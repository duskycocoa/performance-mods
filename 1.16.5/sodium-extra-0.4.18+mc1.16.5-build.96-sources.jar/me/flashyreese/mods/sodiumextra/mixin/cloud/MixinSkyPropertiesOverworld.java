package me.flashyreese.mods.sodiumextra.mixin.cloud;

import me.flashyreese.mods.sodiumextra.client.SodiumExtraClientMod;
import net.minecraft.class_5294;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_5294.class_5297.class)
public abstract class MixinSkyPropertiesOverworld extends class_5294 {
    public MixinSkyPropertiesOverworld(float cloudsHeight, boolean alternateSkyColor, class_5401 skyType, boolean brightenLighting, boolean darkened) {
        super(cloudsHeight, alternateSkyColor, skyType, brightenLighting, darkened);
    }

    @Override
    public float method_28108() {
        return SodiumExtraClientMod.options().extraSettings.cloudHeight;
    }
}
