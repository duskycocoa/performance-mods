package me.flashyreese.mods.sodiumextra.mixin.instant_sneak;

import me.flashyreese.mods.sodiumextra.client.SodiumExtraClientMod;
import net.minecraft.class_1297;
import net.minecraft.class_4184;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_4184.class)
public class MixinCamera {

    @Shadow
    private float cameraY;

    @Shadow
    private class_1297 focusedEntity;

    @Inject(at = @At("HEAD"), method = "updateEyeHeight")
    public void noLerp(CallbackInfo ci) {
        if (SodiumExtraClientMod.options().extraSettings.instantSneak && this.focusedEntity != null) {
            this.cameraY = this.focusedEntity.method_5751();
        }
    }
}