package me.flashyreese.mods.sodiumextra.mixin.light_updates;

import me.flashyreese.mods.sodiumextra.client.SodiumExtraClientMod;
import net.minecraft.class_2338;
import net.minecraft.class_3568;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_3568.class)
public class MixinLightingProvider {
    @Inject(at = @At("HEAD"), method = "checkBlock", cancellable = true)
    public void checkBlock(class_2338 pos, CallbackInfo ci) {
        if (!SodiumExtraClientMod.options().renderSettings.lightUpdates)
            ci.cancel();
    }

    @Inject(at = @At("RETURN"), method = "doLightUpdates", cancellable = true)
    public void doLightUpdates(int maxUpdateCount, boolean doSkylight, boolean skipEdgeLightPropagation, CallbackInfoReturnable<Integer> cir) {
        if (!SodiumExtraClientMod.options().renderSettings.lightUpdates)
            cir.setReturnValue(0);
    }
}
