package me.flashyreese.mods.sodiumextra.mixin.sun_moon;

import me.flashyreese.mods.sodiumextra.client.SodiumExtraClientMod;
import net.minecraft.class_2960;
import net.minecraft.class_5294;
import net.minecraft.class_761;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_761.class)
public class MixinWorldRenderer {

    @Mutable
    @Shadow
    @Final
    private static class_2960 SUN;

    @Mutable
    @Shadow
    @Final
    private static class_2960 MOON_PHASES;

    @Redirect(
            method = "renderSky",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/render/SkyProperties;getFogColorOverride(FF)[F"
            )
    )
    public float[] redirectGetFogColorOverride(class_5294 instance, float skyAngle, float tickDelta) {
        if (SodiumExtraClientMod.options().detailSettings.sunMoon) {
            return instance.method_28109(skyAngle, tickDelta);
        } else {
            return null;
        }
    }

    @Inject(
            method = "reload()V",
            at = @At(value = "TAIL")
    )
    private void postWorldRendererReload(CallbackInfo ci) {
        if (SodiumExtraClientMod.options().detailSettings.sunMoon) {
            MOON_PHASES = new class_2960("textures/environment/moon_phases.png");
            SUN = new class_2960("textures/environment/sun.png");
        } else {
            MOON_PHASES = new class_2960("sodium-extra", "textures/transparent.png");
            SUN = new class_2960("sodium-extra", "textures/transparent.png");
        }
    }
}
