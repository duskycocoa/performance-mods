package me.flashyreese.mods.sodiumextra.mixin.sodium.resolution;

import me.flashyreese.mods.sodiumextra.client.gui.options.control.SliderControlExtended;
import me.flashyreese.mods.sodiumextra.common.util.ControlValueFormatterExtended;
import me.jellysquid.mods.sodium.client.gui.SodiumGameOptionPages;
import me.jellysquid.mods.sodium.client.gui.options.OptionGroup;
import me.jellysquid.mods.sodium.client.gui.options.OptionImpact;
import me.jellysquid.mods.sodium.client.gui.options.OptionImpl;
import me.jellysquid.mods.sodium.client.gui.options.OptionPage;
import me.jellysquid.mods.sodium.client.gui.options.storage.MinecraftOptionsStorage;
import net.minecraft.class_1041;
import net.minecraft.class_2588;
import net.minecraft.class_310;
import net.minecraft.class_319;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

import java.util.List;
import java.util.Optional;

@Mixin(value = SodiumGameOptionPages.class, remap = false)
public class MixinSodiumGameOptionPages {

    @Shadow
    @Final
    private static MinecraftOptionsStorage vanillaOpts;

    @Inject(method = "general", at = @At(value = "INVOKE", target = "Lme/jellysquid/mods/sodium/client/gui/options/OptionGroup;createBuilder()Lme/jellysquid/mods/sodium/client/gui/options/OptionGroup$Builder;", ordinal = 0, shift = At.Shift.BEFORE), locals = LocalCapture.CAPTURE_FAILSOFT, remap = false)
    private static void general(CallbackInfoReturnable<OptionPage> cir, List<OptionGroup> groups) {
        class_1041 window = class_310.method_1551().method_22683();

        groups.add(OptionGroup.createBuilder()
                .add(OptionImpl.createBuilder(int.class, vanillaOpts)
                        .setName(new class_2588("options.fullscreen.resolution").getString())
                        .setTooltip(new class_2588("sodium-extra.option.resolution.tooltip").getString())
                        .setControl(option -> new SliderControlExtended(option, 0, class_310.method_1551().method_22683().method_20831() != null ? class_310.method_1551().method_22683().method_20831().method_1621() : 0, 1, ControlValueFormatterExtended.resolution(), true))
                        .setBinding((options, value) -> {
                            if (window.method_20831() != null) {
                                if (value == 0) {
                                    window.method_4505(Optional.empty());
                                } else {
                                    window.method_4505(Optional.of(window.method_20831().method_1620(value - 1)));
                                }
                            }
                            window.method_4475();
                        }, options -> {
                            if (window.method_20831() == null) {
                                return 0;
                            } else {
                                Optional<class_319> optional = window.method_4511();
                                return optional.map((videoMode) -> window.method_20831().method_1619(videoMode) + 1).orElse(0);
                            }
                        })
                        .setImpact(OptionImpact.HIGH)
                        .build())
                .build());
    }
}
