package me.flashyreese.mods.sodiumextra.mixin.render.entity;

import me.flashyreese.mods.sodiumextra.client.SodiumExtraClientMod;
import net.minecraft.class_1309;
import net.minecraft.class_1531;
import net.minecraft.class_3883;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_583;
import net.minecraft.class_742;
import net.minecraft.class_897;
import net.minecraft.class_898;
import net.minecraft.class_922;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_922.class)
abstract class MixinLivingEntityRenderer<T extends class_1309, M extends class_583<T>> extends class_897<T> implements class_3883<T, M> {

    protected MixinLivingEntityRenderer(class_898 dispatcher) {
        super(dispatcher);
    }

    @Inject(method = "render(Lnet/minecraft/entity/LivingEntity;FFLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V", at = @At("HEAD"), cancellable = true)
    private void onRender(T entity, float f, float g, class_4587 matrixStack, class_4597 vertexConsumerProvider, int i, CallbackInfo ci) {
        if (entity instanceof class_1531 && !SodiumExtraClientMod.options().renderSettings.armorStand) {
            ci.cancel();
            if (this.method_3921(entity)) {
                this.method_3926(entity, entity.method_5476(), matrixStack, vertexConsumerProvider, i);
            }
        }
    }

    @Inject(method = "hasLabel(Lnet/minecraft/entity/LivingEntity;)Z", at = @At(value = "HEAD"), cancellable = true)
    private <T extends class_1309> void hasLabel(T entity, CallbackInfoReturnable<Boolean> cir) {
        if (entity instanceof class_742 && !SodiumExtraClientMod.options().renderSettings.playerNameTag) {
            cir.setReturnValue(false);
        }
    }
}
