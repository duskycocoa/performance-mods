package me.flashyreese.mods.sodiumextra.mixin.animation;

import me.flashyreese.mods.sodiumextra.client.SodiumExtraClientMod;
import net.minecraft.class_1044;
import net.minecraft.class_1058;
import net.minecraft.class_1059;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(class_1059.class)
public abstract class MixinSpriteAtlasTexture extends class_1044 {

    @Redirect(method = "upload", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/texture/Sprite;isAnimated()Z"))
    public boolean sodiumExtra$tickAnimatedSprites(class_1058 instance) {
        return instance.method_4599() && SodiumExtraClientMod.options().animationSettings.animation && this.shouldAnimate(instance);
    }

    private boolean shouldAnimate(class_1058 sprite) {
        if (sprite.method_4598().method_12832().endsWith("water_still") || sprite.method_4598().method_12832().endsWith("water_flow")) {
            return SodiumExtraClientMod.options().animationSettings.water;
        } else if (sprite.method_4598().method_12832().endsWith("lava_still") || sprite.method_4598().method_12832().endsWith("lava_flow")) {
            return SodiumExtraClientMod.options().animationSettings.lava;
        } else if (sprite.method_4598().method_12832().endsWith("nether_portal")) {
            return SodiumExtraClientMod.options().animationSettings.portal;
        } else if (sprite.method_4598().method_12832().endsWith("fire_0") || sprite.method_4598().method_12832().endsWith("fire_1") || sprite.method_4598().method_12832().endsWith("soul_fire_0") ||
                sprite.method_4598().method_12832().endsWith("soul_fire_1") || sprite.method_4598().method_12832().endsWith("campfire_fire") || sprite.method_4598().method_12832().endsWith("campfire_log_lit") ||
                sprite.method_4598().method_12832().endsWith("soul_campfire_fire") || sprite.method_4598().method_12832().endsWith("soul_campfire_log_lit")) {
            return SodiumExtraClientMod.options().animationSettings.fire;
        } else if (sprite.method_4598().method_12832().endsWith("magma") || sprite.method_4598().method_12832().endsWith("lantern") || sprite.method_4598().method_12832().endsWith("sea_lantern") ||
                sprite.method_4598().method_12832().endsWith("soul_lantern") || sprite.method_4598().method_12832().endsWith("kelp") || sprite.method_4598().method_12832().endsWith("kelp_plant") ||
                sprite.method_4598().method_12832().endsWith("seagrass") || sprite.method_4598().method_12832().endsWith("warped_stem") || sprite.method_4598().method_12832().endsWith("crimson_stem") ||
                sprite.method_4598().method_12832().endsWith("blast_furnace_front_on") || sprite.method_4598().method_12832().endsWith("smoker_front_on") ||
                sprite.method_4598().method_12832().endsWith("stonecutter_saw")) {
            return SodiumExtraClientMod.options().animationSettings.blockAnimations;
        }
        return sprite.method_4599();
    }
}
