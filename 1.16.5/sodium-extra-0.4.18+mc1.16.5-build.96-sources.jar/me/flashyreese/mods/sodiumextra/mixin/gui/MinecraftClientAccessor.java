package me.flashyreese.mods.sodiumextra.mixin.gui;

import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_310.class)
public interface MinecraftClientAccessor {
    @Accessor("currentFps")
    static int getCurrentFPS() {
        return 0;
    }
}
