package me.flashyreese.mods.sodiumextra.mixin.stars;

import me.flashyreese.mods.sodiumextra.client.SodiumExtraClientMod;
import net.minecraft.class_638;
import net.minecraft.class_761;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(class_761.class)
public class MixinWorldRenderer {
    @Redirect(
            method = "renderSky",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/world/ClientWorld;method_23787(F)F"
            )
    )
    public float redirectGetStarBrightness(class_638 instance, float f) {
        if (SodiumExtraClientMod.options().detailSettings.stars) {
            return instance.method_23787(f);
        } else {
            return 0.0f;
        }
    }
}
