package me.flashyreese.mods.sodiumextra.mixin.toasts;

import me.flashyreese.mods.sodiumextra.client.SodiumExtraClientMod;
import net.minecraft.class_368;
import net.minecraft.class_370;
import net.minecraft.class_374;
import net.minecraft.class_4587;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_370.class)
public class MixinSystemToast {
    @Inject(method = "draw", at = @At("HEAD"), cancellable = true)
    public void draw(class_4587 matrices, class_374 manager, long startTime, CallbackInfoReturnable<class_368.class_369> cir) {
        if (!SodiumExtraClientMod.options().extraSettings.systemToast) {
            cir.setReturnValue(class_368.class_369.field_2209);
        }
    }
}
