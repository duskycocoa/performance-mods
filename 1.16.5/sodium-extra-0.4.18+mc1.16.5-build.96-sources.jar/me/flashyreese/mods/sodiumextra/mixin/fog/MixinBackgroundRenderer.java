package me.flashyreese.mods.sodiumextra.mixin.fog;

import com.mojang.blaze3d.systems.RenderSystem;
import me.flashyreese.mods.sodiumextra.client.SodiumExtraClientMod;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_3486;
import net.minecraft.class_4184;
import net.minecraft.class_758;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_758.class)
public abstract class MixinBackgroundRenderer {
    @Inject(method = "applyFog", at = @At(value = "TAIL"))
    private static void applyFog(class_4184 camera, class_758.class_4596 fogType, float viewDistance, boolean thickFog, CallbackInfo ci) {
        class_1297 entity = camera.method_19331();
        SodiumExtraClientMod.options().renderSettings.dimensionFogDistanceMap.putIfAbsent(entity.field_6002.method_8597().method_31181(), 0);
        int fogDistance = SodiumExtraClientMod.options().renderSettings.multiDimensionFogControl ? SodiumExtraClientMod.options().renderSettings.dimensionFogDistanceMap.get(entity.field_6002.method_8597().method_31181()) : SodiumExtraClientMod.options().renderSettings.fogDistance;
        if (fogDistance == 0 || (entity instanceof class_1309 && ((class_1309) entity).method_6059(class_1294.field_5919))) {
            return;
        }
        if (!camera.method_19334().method_15767(class_3486.field_15517) && !camera.method_19334().method_15767(class_3486.field_15518) && (thickFog || fogType == class_758.class_4596.field_20946)) {
            float fogStart = (float) SodiumExtraClientMod.options().renderSettings.fogStart / 100;
            if (fogDistance == 33) {
                RenderSystem.fogStart(Short.MAX_VALUE - 1 * fogStart);
                RenderSystem.fogEnd(Short.MAX_VALUE);
            } else {
                RenderSystem.fogStart(fogDistance * 16 * fogStart);
                RenderSystem.fogEnd((fogDistance + 1) * 16);
            }
        }
    }
}
