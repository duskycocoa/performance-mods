package me.flashyreese.mods.sodiumextra.mixin.fog;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.Sets;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.LinkedHashSet;
import net.minecraft.class_5321;
import net.minecraft.class_5363;

@Mixin(class_5363.class)
public interface DimensionOptionsAccessor {
    @Accessor("BASE_DIMENSIONS")
    static LinkedHashSet<class_5321<class_5363>> getBaseDimensions() {
        return Sets.newLinkedHashSet(ImmutableList.of());
    }
}
