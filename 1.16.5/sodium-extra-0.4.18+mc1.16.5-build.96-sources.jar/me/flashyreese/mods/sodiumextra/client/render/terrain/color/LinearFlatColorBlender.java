package me.flashyreese.mods.sodiumextra.client.render.terrain.color;

import me.jellysquid.mods.sodium.client.model.quad.ModelQuadView;
import me.jellysquid.mods.sodium.client.model.quad.blender.SmoothBiomeColorBlender;
import me.jellysquid.mods.sodium.client.util.color.ColorARGB;
import net.minecraft.class_1920;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_322;
import java.util.Arrays;

public class LinearFlatColorBlender extends SmoothBiomeColorBlender {
    @Override
    public int[] getColors(class_322 colorizer, class_1920 world, class_2680 state, class_2338 origin, ModelQuadView quad) {
        int[] colors = super.getColors(colorizer, world, state, origin, quad);
        Arrays.fill(colors, this.getAverageColor(colors));
        return colors;
    }

    private int getAverageColor(int[] colors) {
        int a = Arrays.stream(colors).map(ColorARGB::unpackAlpha).sum();
        int r = Arrays.stream(colors).map(ColorARGB::unpackRed).sum();
        int g = Arrays.stream(colors).map(ColorARGB::unpackGreen).sum();
        int b = Arrays.stream(colors).map(ColorARGB::unpackBlue).sum();

        return ColorARGB.pack(r / colors.length, g / colors.length, b / colors.length, a / colors.length);
    }
}
