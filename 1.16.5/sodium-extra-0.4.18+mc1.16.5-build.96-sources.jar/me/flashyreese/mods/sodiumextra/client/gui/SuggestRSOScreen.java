package me.flashyreese.mods.sodiumextra.client.gui;

import me.flashyreese.mods.sodiumextra.client.SodiumExtraClientMod;
import net.minecraft.class_124;
import net.minecraft.class_156;
import net.minecraft.class_2561;
import net.minecraft.class_2585;
import net.minecraft.class_2588;
import net.minecraft.class_4185;
import net.minecraft.class_4286;
import net.minecraft.class_437;
import net.minecraft.class_4587;
import net.minecraft.class_5244;
import net.minecraft.class_5489;

public class SuggestRSOScreen extends class_437 {

    private static final class_2561 HEADER = new class_2588("sodium-extra.suggestRSO.header").method_27692(class_124.field_1067);
    private static final class_2561 MESSAGE = new class_2588("sodium-extra.suggestRSO.message");
    private static final class_2561 CHECK_MESSAGE = new class_2588("multiplayerWarning.check");
    private static final class_2561 PROCEED_TEXT = HEADER.method_27661().method_27693("\n").method_10852(MESSAGE);
    private final class_437 prevScreen;
    private class_4286 checkbox;
    private class_5489 lines = class_5489.field_26528;

    public SuggestRSOScreen(class_437 prevScreen) {
        super(new class_2585("Reese's Sodium Options Suggestion"));
        this.prevScreen = prevScreen;
    }

    @Override
    protected void method_25426() {
        super.method_25426();
        this.lines = class_5489.method_30890(this.field_22793, MESSAGE, this.field_22789 - 50);
        int i = (this.lines.method_30887() + 1) * this.field_22793.field_2000 * 2;
        this.method_25411(new class_4185(this.field_22789 / 2 - 155, 130 + i, 150, 20, new class_2585("CurseForge"), buttonWidget -> class_156.method_668().method_670("https://curseforge.com/minecraft/mc-mods/reeses-sodium-options")));
        this.method_25411(new class_4185(this.field_22789 / 2 - 155 + 160, 130 + i, 150, 20, new class_2585("Modrinth"), buttonWidget -> class_156.method_668().method_670("https://modrinth.com/mod/reeses-sodium-options")));
        this.method_25411(new class_4185(this.field_22789 / 2 - 155, 100 + i, 150, 20, class_5244.field_24338, buttonWidget -> {
            if (this.checkbox.method_20372()) {
                SodiumExtraClientMod.options().notificationSettings.hideRSORecommendation = true;
                SodiumExtraClientMod.options().writeChanges();
            }
            this.field_22787.method_1507(this.prevScreen);
        }));
        this.method_25411(new class_4185(this.field_22789 / 2 - 155 + 160, 100 + i, 150, 20, new class_2588("menu.quit"), buttonWidget -> this.field_22787.method_1592()));
        this.checkbox = new class_4286(this.field_22789 / 2 - 155 + 80, 76 + i, 150, 20, CHECK_MESSAGE, false);
        this.method_25411(this.checkbox);
    }

    @Override
    public String method_25435() {
        return PROCEED_TEXT.getString();
    }

    @Override
    public void method_25394(class_4587 matrices, int mouseX, int mouseY, float delta) {
        this.method_25434(0);
        method_27535(matrices, this.field_22793, HEADER, 25, 30, 0xFFFFFF);
        this.lines.method_30893(matrices, 25, 70, this.field_22793.field_2000 * 2, 0xFFFFFF);
        super.method_25394(matrices, mouseX, mouseY, delta);
    }
}
