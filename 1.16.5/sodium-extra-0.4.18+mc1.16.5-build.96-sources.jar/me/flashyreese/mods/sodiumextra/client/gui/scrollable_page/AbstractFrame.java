package me.flashyreese.mods.sodiumextra.client.gui.scrollable_page;

import com.mojang.blaze3d.systems.RenderSystem;
import me.jellysquid.mods.sodium.client.gui.options.control.ControlElement;
import me.jellysquid.mods.sodium.client.gui.widgets.AbstractWidget;
import me.jellysquid.mods.sodium.client.util.Dim2i;
import net.minecraft.class_310;
import net.minecraft.class_364;
import net.minecraft.class_4068;
import net.minecraft.class_4069;
import net.minecraft.class_4587;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;

public abstract class AbstractFrame extends AbstractWidget implements class_4069 {
    protected final Dim2i dim;
    protected final List<AbstractWidget> children = new ArrayList<>();
    protected final List<class_4068> drawable = new ArrayList<>();
    protected final List<ControlElement<?>> controlElements = new ArrayList<>();
    private class_364 focused;
    private boolean dragging;

    public AbstractFrame(Dim2i dim) {
        this.dim = dim;
    }

    public void buildFrame() {
        for (class_364 element : this.children) {
            if (element instanceof AbstractFrame) {
                this.controlElements.addAll(((AbstractFrame) element).controlElements);
            }
            if (element instanceof ControlElement<?>) {
                this.controlElements.add((ControlElement<?>) element);
            }
            if (element instanceof class_4068) {
                this.drawable.add((class_4068) element);
            }
        }
    }

    @Override
    public void method_25394(class_4587 matrices, int mouseX, int mouseY, float delta) {
        for (class_4068 drawable : this.drawable) {
            drawable.method_25394(matrices, mouseX, mouseY, delta);
        }
    }

    public void applyScissor(int x, int y, int width, int height, Runnable action) {
        double scale = class_310.method_1551().method_22683().method_4495();
        RenderSystem.enableScissor((int) (x * scale), (int) (class_310.method_1551().method_22683().method_4506() - (y + height) * scale),
                (int) (width * scale), (int) (height * scale));
        action.run();
        RenderSystem.disableScissor();
    }

    @Override
    public boolean method_25397() {
        return this.dragging;
    }

    @Override
    public void method_25398(boolean dragging) {
        this.dragging = dragging;
    }

    @Nullable
    @Override
    public class_364 method_25399() {
        return this.focused;
    }

    @Override
    public void method_25395(@Nullable class_364 focused) {
        this.focused = focused;
    }

    @Override
    public List<? extends class_364> method_25396() {
        return this.children;
    }

    @Override
    public boolean method_25405(double mouseX, double mouseY) {
        return this.dim.containsCursor(mouseX, mouseY);
    }
}