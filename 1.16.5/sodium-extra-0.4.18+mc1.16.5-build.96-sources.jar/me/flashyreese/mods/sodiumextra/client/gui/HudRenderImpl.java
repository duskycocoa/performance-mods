package me.flashyreese.mods.sodiumextra.client.gui;

import me.flashyreese.mods.sodiumextra.client.SodiumExtraClientMod;
import me.flashyreese.mods.sodiumextra.mixin.gui.MinecraftClientAccessor;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2585;
import net.minecraft.class_2588;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4587;

public class HudRenderImpl implements HudRenderCallback {

    private final class_310 client = class_310.method_1551();

    @Override
    public void onHudRender(class_4587 matrixStack, float tickDelta) {
        if (!this.client.field_1690.field_1866) {
            //Gotta love hardcoding
            if (SodiumExtraClientMod.options().extraSettings.showFps && SodiumExtraClientMod.options().extraSettings.showCoords) {
                this.renderFPS(matrixStack);
                this.renderCoords(matrixStack);
            } else if (SodiumExtraClientMod.options().extraSettings.showFps) {
                this.renderFPS(matrixStack);
            } else if (SodiumExtraClientMod.options().extraSettings.showCoords) {
                this.renderCoords(matrixStack);
            }
            if (!SodiumExtraClientMod.options().renderSettings.lightUpdates) {
                this.renderLightUpdatesWarning(matrixStack);
            }
        }
    }

    //Should I make this OOP or just leave as it :> I don't think I will be adding any more than these 2.
    private void renderFPS(class_4587 matrices) {
        int currentFPS = MinecraftClientAccessor.getCurrentFPS();

        class_2561 text = new class_2588("sodium-extra.overlay.fps", currentFPS);

        if (SodiumExtraClientMod.options().extraSettings.showFPSExtended)
            text = new class_2585(String.format("%s %s", text.getString(), new class_2588("sodium-extra.overlay.fps_extended", SodiumExtraClientMod.getClientTickHandler().getHighestFps(), SodiumExtraClientMod.getClientTickHandler().getAverageFps(),
                    SodiumExtraClientMod.getClientTickHandler().getLowestFps()).getString()));

        int x = 0, y = 0;
        switch (SodiumExtraClientMod.options().extraSettings.overlayCorner) {
            case TOP_LEFT:
                x = 2;
                y = 2;
                break;
            case TOP_RIGHT:
                x = this.client.method_22683().method_4486() - this.client.field_1772.method_27525(text) - 2;
                y = 2;
                break;
            case BOTTOM_LEFT:
                x = 2;
                y = this.client.method_22683().method_4502() - this.client.field_1772.field_2000 - 2;
                break;
            case BOTTOM_RIGHT:
                x = this.client.method_22683().method_4486() - this.client.field_1772.method_27525(text) - 2;
                y = this.client.method_22683().method_4502() - this.client.field_1772.field_2000 - 2;
                break;
        }

        this.drawString(matrices, text, x, y);
    }

    private void renderCoords(class_4587 matrices) {
        if (this.client.field_1724 == null) return;
        if (this.client.method_1555()) return;
        class_243 pos = this.client.field_1724.method_19538();

        class_2561 text = new class_2588("sodium-extra.overlay.coordinates", String.format("%.2f", pos.field_1352), String.format("%.2f", pos.field_1351), String.format("%.2f", pos.field_1350));

        int x = 0, y = 0;
        switch (SodiumExtraClientMod.options().extraSettings.overlayCorner) {
            case TOP_LEFT:
                x = 2;
                y = 12;
                break;
            case TOP_RIGHT:
                x = this.client.method_22683().method_4486() - this.client.field_1772.method_27525(text) - 2;
                y = 12;
                break;
            case BOTTOM_LEFT:
                x = 2;
                y = this.client.method_22683().method_4502() - this.client.field_1772.field_2000 - 12;
                break;
            case BOTTOM_RIGHT:
                x = this.client.method_22683().method_4486() - this.client.field_1772.method_27525(text) - 2;
                y = this.client.method_22683().method_4502() - this.client.field_1772.field_2000 - 12;
                break;
        }

        this.drawString(matrices, text, x, y);
    }

    private void renderLightUpdatesWarning(class_4587 matrices) {
        class_2561 text = new class_2588("sodium-extra.overlay.light_updates");

        int x = 0, y = 0;
        switch (SodiumExtraClientMod.options().extraSettings.overlayCorner) {
            case TOP_LEFT:
                x = 2;
                y = 22;
                break;
            case TOP_RIGHT:
                x = this.client.method_22683().method_4486() - this.client.field_1772.method_27525(text) - 2;
                y = 22;
                break;
            case BOTTOM_LEFT:
                x = 2;
                y = this.client.method_22683().method_4502() - this.client.field_1772.field_2000 - 22;
                break;
            case BOTTOM_RIGHT:
                x = this.client.method_22683().method_4486() - this.client.field_1772.method_27525(text) - 2;
                y = this.client.method_22683().method_4502() - this.client.field_1772.field_2000 - 22;
                break;
        }

        this.drawString(matrices, text, x, y);
    }

    private void drawString(class_4587 matrices, class_2561 text, int x, int y) {
        if (SodiumExtraClientMod.options().extraSettings.textContrast == SodiumExtraGameOptions.TextContrast.NONE) {
            this.client.field_1772.method_30883(matrices, text, x, y, 0xffffffff);
        } else if (SodiumExtraClientMod.options().extraSettings.textContrast == SodiumExtraGameOptions.TextContrast.BACKGROUND) {
            class_332.method_25294(matrices, x - 1, y - 1, x + this.client.field_1772.method_27525(text) + 1, y + this.client.field_1772.field_2000, -1873784752);
            this.client.field_1772.method_30883(matrices, text, x, y, 0xffffffff);
        } else if (SodiumExtraClientMod.options().extraSettings.textContrast == SodiumExtraGameOptions.TextContrast.SHADOW) {
            this.client.field_1772.method_30881(matrices, text, x, y, 0xffffffff);
        }
    }
}
