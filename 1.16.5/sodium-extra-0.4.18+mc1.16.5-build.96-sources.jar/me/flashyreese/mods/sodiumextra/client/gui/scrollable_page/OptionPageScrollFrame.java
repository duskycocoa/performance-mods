package me.flashyreese.mods.sodiumextra.client.gui.scrollable_page;

import me.jellysquid.mods.sodium.client.gui.options.Option;
import me.jellysquid.mods.sodium.client.gui.options.OptionGroup;
import me.jellysquid.mods.sodium.client.gui.options.OptionImpact;
import me.jellysquid.mods.sodium.client.gui.options.OptionPage;
import me.jellysquid.mods.sodium.client.gui.options.control.Control;
import me.jellysquid.mods.sodium.client.gui.options.control.ControlElement;
import me.jellysquid.mods.sodium.client.util.Dim2i;
import net.minecraft.class_124;
import net.minecraft.class_2477;
import net.minecraft.class_2585;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_5481;
import java.util.ArrayList;
import java.util.List;

public class OptionPageScrollFrame extends AbstractFrame {
    protected final OptionPage page;
    private boolean canScroll;
    private ScrollBarComponent scrollBar = null;

    public OptionPageScrollFrame(Dim2i dim, OptionPage page) {
        super(dim);
        this.page = page;
        this.setupFrame();
        this.buildFrame();
    }

    public void setupFrame() {
        this.children.clear();
        this.drawable.clear();
        this.controlElements.clear();

        int y = 0;
        if (!this.page.getGroups().isEmpty()) {
            OptionGroup lastGroup = this.page.getGroups().get(this.page.getGroups().size() - 1);

            for (OptionGroup group : this.page.getGroups()) {
                y += group.getOptions().size() * 18;
                if (group != lastGroup) {
                    y += 4;
                }
            }
        }

        this.canScroll = this.dim.getHeight() < y;
        if (this.canScroll) {
            this.scrollBar = new ScrollBarComponent(new Dim2i(this.dim.getLimitX() - 10, this.dim.getOriginY(), 10, this.dim.getHeight()), y, this.dim.getHeight(), this::buildFrame, this.dim);
        }
    }

    @Override
    public void buildFrame() {
        if (this.page == null) return;

        this.children.clear();
        this.drawable.clear();
        this.controlElements.clear();

        int y = 0;
        for (OptionGroup group : this.page.getGroups()) {
            // Add each option's control element
            for (Option<?> option : group.getOptions()) {
                Control<?> control = option.getControl();
                ControlElement<?> element = control.createElement(new Dim2i(this.dim.getOriginX(), this.dim.getOriginY() + y - (this.canScroll ? this.scrollBar.getOffset() : 0), this.dim.getWidth() - (this.canScroll ? 11 : 0), 18));
                this.children.add(element);

                // Move down to the next option
                y += 18;
            }

            // Add padding beneath each option group
            y += 4;
        }

        if (this.canScroll) {
            this.scrollBar.updateThumbPosition();
        }

        super.buildFrame();
    }

    @Override
    public void method_25394(class_4587 matrices, int mouseX, int mouseY, float delta) {
        ControlElement<?> hoveredElement = this.controlElements.stream()
                .filter(ControlElement::isHovered)
                .findFirst()
                .orElse(null);
        matrices.method_22903();
        this.applyScissor(this.dim.getOriginX(), this.dim.getOriginY(), this.dim.getWidth(), this.dim.getHeight(), () -> super.method_25394(matrices, mouseX, mouseY, delta));
        matrices.method_22909();
        if (this.canScroll) {
            this.scrollBar.method_25394(matrices, mouseX, mouseY, delta);
        }
        if (this.dim.containsCursor(mouseX, mouseY) && hoveredElement != null) {
            this.renderOptionTooltip(matrices, hoveredElement);
        }
    }

    private void renderOptionTooltip(class_4587 matrixStack, ControlElement<?> element) {
        Dim2i dim = element.getDimensions();

        int textPadding = 3;
        int boxPadding = 3;

        int boxWidth = 200;

        int boxY = Math.max(dim.getOriginY(), this.dim.getOriginY());
        int boxX = this.dim.getLimitX() + boxPadding;

        Option<?> option = element.getOption();
        List<class_5481> tooltip = new ArrayList<>(class_310.method_1551().field_1772.method_1728(option.getTooltip(), boxWidth - textPadding * 2));
        OptionImpact impact = option.getImpact();
        if (impact != null) {
            tooltip.add(class_2477.method_10517().method_30934(new class_2585(class_124.field_1080 + "Performance Impact: " + impact.toDisplayString())));
        }

        /*if (option.getFlags().contains(OptionFlag.REQUIRES_GAME_RESTART)) {
            tooltip.add(Language.getInstance().reorder(Text.translatable("sodium.option_flag.requires_game_restart.tooltip").formatted(Formatting.RED)));
        }*/

        int boxHeight = (tooltip.size() * 12) + boxPadding;
        int boxYLimit = boxY + boxHeight;
        int boxYCutoff = this.dim.getLimitY() - 25 /*- 64*/;

        // If the box is going to be cutoff on the Y-axis, move it back up the difference
        if (boxYLimit > boxYCutoff) {
            boxY -= boxYLimit - boxYCutoff;
        }

        this.drawRect(boxX, boxY, boxX + boxWidth, boxY + boxHeight, 0xE0000000);

        for (int i = 0; i < tooltip.size(); i++) {
            class_310.method_1551().field_1772.method_27528(matrixStack, tooltip.get(i), boxX + textPadding, boxY + textPadding + (i * 12), 0xFFFFFFFF);
        }
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        if (this.dim.containsCursor(mouseX, mouseY) && super.method_25402(mouseX, mouseY, button)) {
            return true;
        }
        if (this.canScroll) {
            return this.scrollBar.method_25402(mouseX, mouseY, button);
        }
        return false;
    }

    @Override
    public boolean method_25403(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (super.method_25403(mouseX, mouseY, button, deltaX, deltaY)) {
            return true;
        }
        if (this.canScroll) {
            return this.scrollBar.method_25403(mouseX, mouseY, button, deltaX, deltaY);
        }
        return false;
    }

    @Override
    public boolean method_25406(double mouseX, double mouseY, int button) {
        if (super.method_25406(mouseX, mouseY, button)) {
            return true;
        }
        if (this.canScroll) {
            return this.scrollBar.method_25406(mouseX, mouseY, button);
        }
        return false;
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double amount) {
        if (super.method_25401(mouseX, mouseY, amount)) {
            return true;
        }
        if (this.canScroll) {
            return this.scrollBar.method_25401(mouseX, mouseY, amount);
        }
        return false;
    }
}